export const CATEGORIES = {
  PAINTING: {
    key: "painting",
    title: "نقاشی",
  },
  GRAPHIC: {
    key: "graphic",
    title: "گرافیک",
  },
  PHOTOGRAPHY: {
    key: "photography",
    title: "عکاسی",
  },
  ACHIEVEMENTS: {
    key: "achievements",
    title: "دستاوردها",
  },
};
