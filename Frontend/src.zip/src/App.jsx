import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useState, useEffect } from "react";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import MainLayout from "./layout/MainLayout";
import Login from "./pages/Login";
import Register from "./pages/Register";
import ProtectedRoute from "./components/ProtectedRoute";
import { ToastContainer } from "react-toastify";
import DashboardPage from "./pages/DashboardPage";
import Printing from "./pages/Printing";
import GeraphicPage from "./pages/GeraphicPage";
import InterviewPage from "./pages/InterviewPage";
import ExhibitionPage from "./pages/ExhibitionPage";
import Contact from "./pages/Contact";
import TheaterPage from "./pages/ChildrenPage";
import MiscellaneousPage from "./pages/MiscellaneousPage";
import DesignPage from "./pages/DesignPage";
import AchievementsPage from "./pages/AchievementsPage";
import ScrollToTop from "./components/ScrollToTop";
import ChildrenPage from "./pages/ChildrenPage";
import PageNotFound from "./pages/PageNotFound";


function App() {
  return (
    <>
      <BrowserRouter>
        <ScrollToTop />
        <Routes>
          {/* Public pages */}
          <Route path="/" element={<MainLayout />}>
            <Route index element={<Home />} />
            <Route path="/painting" element={<Printing />} />
            <Route path="/graphic" element={<GeraphicPage />} />
            <Route path="/interview" element={<InterviewPage />} />
            <Route path="/exhibition" element={<ExhibitionPage />} />
            <Route path="/children" element={<ChildrenPage />} />
            <Route path="/achivment" element={<AchievementsPage />} />
            <Route path="/miscellaneous" element={<MiscellaneousPage />} />
            <Route path="/design" element={<DesignPage />} />
            <Route path="/contact" element={<Contact />} />
          </Route>

          {/* Auth pages */}
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/*" element={<PageNotFound />} />

          {/* Protected Dashboard */}
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <DashboardPage />
              </ProtectedRoute>
            }
          />
        </Routes>
      </BrowserRouter>

      <ToastContainer
        position="top-right"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop={true}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
      />
    </>
  );
}

export default App;
