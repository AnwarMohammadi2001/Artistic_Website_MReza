import React from "react";
import Category from "./Category";

const Design = () => {
  return <div><Category /></div>;
};

export default Design;
