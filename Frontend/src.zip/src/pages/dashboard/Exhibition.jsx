import React from "react";

const Exhibition = () => {
  return <div>exhibition</div>;
};

export default Exhibition;
