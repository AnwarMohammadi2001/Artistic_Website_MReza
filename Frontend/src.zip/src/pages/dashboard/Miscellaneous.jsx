import React from "react";

const Miscellaneous = () => {
  return <div>miscellaneous</div>;
};

export default Miscellaneous;
