import React from 'react'

const Geraphic = () => {
  return <div>geraphic</div>;
}

export default Geraphic
