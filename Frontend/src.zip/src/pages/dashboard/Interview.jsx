import React from "react";

const Interview = () => {
  return <div>interview</div>;
};

export default Interview;
