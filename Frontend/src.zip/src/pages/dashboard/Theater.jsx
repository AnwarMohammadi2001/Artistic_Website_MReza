import React from "react";

const Theater = () => {
  return <div>theater</div>;
};

export default Theater;
